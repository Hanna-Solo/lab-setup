# scripts/

Place small helper scripts here (e.g., automation to start containers, sanitize logs).
**Do not** store or share exploit code or any script that targets live systems.
